import copy
import numpy as np

### Constants ###
EQUATORIAL_RADIUS = 6378137.0
POLAR_RADIUS = 6356752.0
EPSG_3857_EXT_X = np.pi * EQUATORIAL_RADIUS
EPSG_3857_EXT_Y = 20048966.104014594
LINE_INTERSECT_TOL = 1e-9

config_dict_std = {
    "gps_env": False,
    "env_bounds": [160.0, 80.0],
    "env_bounds_unit": "m",
    "blue_flag_home": "auto",
    "red_flag_home": "auto",
    "flag_homes_unit": "m",
    "scrimmage_coords": "auto",
    "scrimmage_coords_unit": "m",
    "topo_contour_eps": 0.001,
    "agent_radius": 2.0,
    "flag_radius": 2.0,
    "flag_keepout": 3.0,
    "catch_radius": 10.0,
    "slip_radius": 10.0,
    "n_circle_segments": 8,
    "obstacles": None,
    "oob_speed_frac": 0.5,
    "dynamics": "surveyor",
    "tau": 0.1,
    "sim_speedup_factor": 1,
    "default_init": True,
    "max_score": 20,
    "max_time": 600.0,
    "tagging_cooldown": 60.0,
    "tag_on_collision": False,
    "tag_on_oob": True,
    "normalize_obs": True,
    "short_obs_hist_length": 1,
    "short_obs_hist_interval": 1,
    "long_obs_hist_length": 1,
    "long_obs_hist_interval": 4,
    "lidar_obs": False,
    "lidar_range": 200.0,
    "num_lidar_rays": 50,
    "normalize_state": True,
    "short_state_hist_length": 1,
    "short_state_hist_interval": 1,
    "long_state_hist_length": 1,
    "long_state_hist_interval": 4,
    "render_fps": 30,
    "screen_frac": 0.90,
    "arena_buffer_frac": 0.05,
    "render_agent_ids": False,
    "render_field_points": False,
    "render_traj_mode": None,
    "render_traj_freq": 1,
    "render_traj_cutoff": None,
    "render_lidar_mode": None,
    "render_saving": False,
    "render_transparency_alpha": 128,
    "suppress_numpy_warnings": True,
}

# Backwards-compatible alias expected by some helpers.
config_dict_competition = config_dict_std


def get_std_config() -> dict:
    return copy.deepcopy(config_dict_std)


lidar_detection_classes = [
    "nothing", "obstacle", "team_flag", "opponent_flag", "teammate",
    "teammate_is_tagged", "teammate_has_flag", "opponent",
    "opponent_is_tagged", "opponent_has_flag",
]
LIDAR_DETECTION_CLASS_MAP = {class_name: i for i, class_name in enumerate(lidar_detection_classes)}

ACTION_MAP = []
for spd in [1.0, 0.5]:
    for hdg in range(180, -180, -45):
        ACTION_MAP.append([spd, hdg])
ACTION_MAP.append([0.0, 0.0])
